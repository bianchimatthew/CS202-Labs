// Matthew Bianchi Connect4 Interactive game 
#include "C4Board.h"   // class definition for C4Board used below
#include <iostream>
using namespace std;


int main() {
    C4Board c4;   // instantiate an instance of a C4Board object
    c4.play();    // play game!!
    return 0;
}
